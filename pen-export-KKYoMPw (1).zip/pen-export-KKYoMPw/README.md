# 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Static-animation/pen/KKYoMPw](https://codepen.io/Static-animation/pen/KKYoMPw).

